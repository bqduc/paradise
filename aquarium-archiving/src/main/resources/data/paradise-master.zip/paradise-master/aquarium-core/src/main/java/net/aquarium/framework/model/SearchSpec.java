/**
 * 
 */
package net.aquarium.framework.model;

/**
 * @author bqduc
 *
 */
public abstract class SearchSpec {
}
