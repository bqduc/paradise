/**
 * 
 */
package net.aquarium.css.model;

/**
 * @author bqduc
 *
 */
public enum InventoryType {
	Unknown,
	Book, 
	Document,
	Material,
	SemiProduct,
	FinalProduct,
	Service
}
