/**
 * 
 */
package net.aquarium.css.model;

/**
 * @author bqduc
 *
 */
public enum EnterpriseClassType {
	CorporateGroup,
	Subsidiary,
	HeadOffice,
	Branch, 
	Office,
	Cooperative, //An office or group of people working in another company
	Representative
}
