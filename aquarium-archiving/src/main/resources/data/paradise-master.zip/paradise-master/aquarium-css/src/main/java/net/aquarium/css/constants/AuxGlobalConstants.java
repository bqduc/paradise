/**
 * 
 */
package net.aquarium.css.constants;

/**
 * @author ducbui
 *
 */
public class AuxGlobalConstants {
	public static final String realmBasic  = "paramountBasicRealm";
}
