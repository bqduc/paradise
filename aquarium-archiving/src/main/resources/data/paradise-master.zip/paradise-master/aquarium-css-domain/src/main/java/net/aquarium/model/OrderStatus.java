/**
 * 
 */
package net.aquarium.model;

/**
 * @author ducbq
 *
 */
public enum OrderStatus {
	Open,
	Canceled,
	Rejected,
	Approved,
	Processing,
	Closed
}
