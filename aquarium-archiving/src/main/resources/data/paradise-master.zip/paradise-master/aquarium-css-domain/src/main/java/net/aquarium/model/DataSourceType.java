/**
 * 
 */
package net.aquarium.model;

/**
 * @author bqduc
 *
 */
public enum DataSourceType {
	UNKNOWN,
	CSV,
	EXCEL
}
