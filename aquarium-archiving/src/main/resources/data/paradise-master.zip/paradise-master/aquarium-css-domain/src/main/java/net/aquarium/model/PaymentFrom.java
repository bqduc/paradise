/**
 * 
 */
package net.aquarium.model;

/**
 * @author ducbq
 *
 */
public enum PaymentFrom {
  Account,    
  BankAccount 
}
