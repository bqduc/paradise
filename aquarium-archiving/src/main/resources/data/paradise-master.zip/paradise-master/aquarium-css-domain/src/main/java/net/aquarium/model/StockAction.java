/**
 * 
 */
package net.aquarium.model;

/**
 * @author ducbq
 *
 */
public enum StockAction {
	STOCK_IN,
	STOCK_OUT,
	STOCK_TRANSFER,
	STOCK_VERIMENT,
	STOCK_VIREMENT, 
	STOCK_RECONCILE
}
