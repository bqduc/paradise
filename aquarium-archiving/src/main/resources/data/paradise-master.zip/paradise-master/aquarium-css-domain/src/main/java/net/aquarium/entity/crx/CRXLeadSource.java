/**
 * 
 */
package net.aquarium.entity.crx;

/**
 * @author bqduc
 *
 */
public enum CRXLeadSource {
	ColdCall, 
	ExistingCustomer, 
	SelfGenerated, 
	Employee

}
