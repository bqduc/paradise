/**
 * 
 */
package net.aquarium.model;

/**
 * @author ducbq
 *
 */
public enum AccountType {
  Cashbook,
  Bank,
  Department
}
