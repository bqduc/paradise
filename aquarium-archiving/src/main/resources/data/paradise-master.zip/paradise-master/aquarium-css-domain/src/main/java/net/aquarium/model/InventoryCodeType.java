/**
 * 
 */
package net.aquarium.model;

/**
 * @author bqduc
 *
 */
public enum InventoryCodeType {
	Unknown,
	ASIN,
	ISBN,
	UPC,
	EAN
}
