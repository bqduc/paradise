/**
 * 
 */
package net.aquarium.model;

/**
 * @author bqduc
 *
 */
public enum BusinessClass {
	SuperSaverClass,
	SaverClass, 
	EconomicClass,
	BusinessClass,
	VIPClass
}
