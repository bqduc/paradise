/**
 * 
 */
package net.aquarium.auth.constants;

import net.aquarium.auth.domain.BaseACL;

/**
 * @author ducbui
 *
 */
public class AuxGlobalConstants {
	public static final String _SALT_EXTENDED = "裴达克·奎-裴达克·奎";
	public static final String realmBasic  = "paramountBasicRealm";

	
	public static final String MINIMUM_USER_AUTHORITY = BaseACL.SUBSCRIBER.getAuthority();// "minUserAuthority";
	
}
