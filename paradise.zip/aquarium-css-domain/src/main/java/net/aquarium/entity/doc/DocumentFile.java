/*
 * Copyleft 2007-2011 Ozgur Yazilim A.S.
 *
 * Distributable under LGPL license.
 * See terms of license at gnu.org.
 * http://www.gnu.org/licenses/lgpl.html
 *
 * www.tekir.com.tr
 * www.ozguryazilim.com.tr
 *
 */

package net.aquarium.entity.doc;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import lombok.Data;
import net.aquarium.entity.contact.CTAContact;
import net.aquarium.entity.trade.OwnerType;
import net.aquarium.framework.entity.RepoEntity;

/**
 *
 * @author haky
 */
@Data
@Entity
@Table(name = "DOCUMENT_FILE")
public class DocumentFile extends RepoEntity {

	private static final long serialVersionUID = 1L;

	@ManyToOne
	@JoinColumn(name = "CONTACT_ID")
	private CTAContact contact;

	@Column(name = "NAME")
	private String name;

	@Column(name = "UPDATE_DATE")
	@Temporal(value = TemporalType.DATE)
	private Date updateDate;

	@Column(name = "TITLE")
	private String title;

	@Column(name = "DOC_TYPE")
	@Enumerated(EnumType.ORDINAL)
	private DocumentFileType docType;

	@Column(name = "FORMAT")
	private String format; // Upload sırasında MIME gelecek.

	@Column(name = "INFO")
	private String info;

	@Column(name = "user_info") // dosyayı upload eden user
	private String user;

	@Column(name = "URL")
	private String url;

	@Column(name = "ACTIVE")
	private Boolean active;

	@Column(name = "FILE_SIZE")
	private Integer fileSize;

	@Column(name = "DOC_QUANTITY")
	private Integer quantity;

	@Column(name = "OWNER_TYPE")
	@Enumerated(EnumType.ORDINAL)
	private OwnerType ownerType;

	/**
	 * Returns a string representation of the object. This implementation constructs that representation based on the id fields.
	 * 
	 * @return a string representation of the object.
	 */
	@Override
	public String toString() {
		return "com.ut.ttdoc.entities.Document[id=" + getId() + "]";
	}
}
