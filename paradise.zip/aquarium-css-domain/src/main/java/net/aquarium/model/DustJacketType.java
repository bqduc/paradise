/**
 * 
 */
package net.aquarium.model;

/**
 * @author bqduc
 *
 */
public enum DustJacketType {
	Unknown,
	NoDustJacket,
	LikeNew,
	VeryGood,
	Good,
	Acceptable
}
