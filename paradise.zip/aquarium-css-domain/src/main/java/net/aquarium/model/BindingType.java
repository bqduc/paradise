/**
 * 
 */
package net.aquarium.model;

/**
 * @author bqduc
 *
 */
public enum BindingType {
	Unknown,
	Hardcover, 
	Paperback
}
