/**
 * 
 */
package net.aquarium.domain.model.dto;

import java.io.Serializable;

/**
 * @author ducbq
 *
 */
public abstract class FacadeCore implements Serializable {
	private static final long serialVersionUID = -7995819403977686541L;

}
