/**
 * 
 */
package net.aquarium.framework.validation;

/**
 * @author ducbq
 *
 */
public interface Validator {
	boolean isValid(String token);
}
