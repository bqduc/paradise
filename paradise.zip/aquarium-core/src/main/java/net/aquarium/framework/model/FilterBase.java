/**
 * 
 */
package net.aquarium.framework.model;

/**
 * @author ducbq
 *
 */
public class FilterBase {
/*	@Getter
	@Setter
	private String code;

	@Getter
	@Setter
	private String info;*/
}
