/**
 * 
 */
package net.aquarium.css.model;

/**
 * @author bqduc
 *
 */
public enum DataSourceType {
	UNKNOWN,
	CSV,
	EXCEL
}
