/**
 * 
 */
package net.aquarium.css.model;

/**
 * @author bqduc
 *
 */
public enum BusinessClass {
	SuperSaverClass,
	SaverClass, 
	EconomicClass,
	BusinessClass,
	VIPClass
}
