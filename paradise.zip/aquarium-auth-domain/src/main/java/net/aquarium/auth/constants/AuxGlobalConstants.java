package net.aquarium.auth.constants;
/**
 * 
 *//*
package net.paramount.auth.constants;

*//**
 * @author ducbui
 *
 *//*
public class AuxGlobalConstants {
	public static final String realmBasic  = "paramountBasicRealm";
}
*/